<div class="row">
    <div class="col-md-12">
        <div class="text-center">
            <img src="img/footage.jpeg" alt="Putri patimah" width="160" class="rounded-circle">
            <table class="table mt-4" style="width:100%; margin:0 auto;">
                <tbody>
                    <tr>
                        <td align="right" width="50%"><strong>NPM</strong></td>
                        <td align="left" width="50%">2110010027</td>
                    </tr>
                    <tr>
                        <td align="right" width="50%"><strong>Fakultas / Program Studio :</strong></td>
                        <td align="left" width="50%">Teknologi Informasi / Teknik Informatika</td>
                    </tr>
                    <tr>
                        <td align="right" width="50%"><strong>Nama Lengkap :</strong></td>
                        <td align="left" width="50%">Putri Patimah</td>
                    </tr>
                    <tr>
                        <td align="right" width="50%"><strong>Tempat, Tanggal Lahir :</strong></td>
                        <td align="left" width="50%">Amuntai, 18 september 2003</td>
                    </tr>
                    <tr>
                        <td align="right" width="50%"><strong>Telepon :</strong></td>
                        <td align="left" width="50%">0857-3412-4312</td>
                    </tr>
                    <tr>
                        <td align="right" width="50%"><strong>email :</strong></td>
                        <td align="left" width="50%">ppatimah720@gmail.com</td>
                    </tr>
                    <tr>
                        <td align="right" width="50%"><strong>Media Sosial :</strong></td>
                        <td align="left" width="50%">
                            <a href="https://www.facebook.com/profile.php?id=100037559152201" target="_blank" style="text-decoration:none;">
                                <img src="img/medsos/facebookgmbr.png" width="30" alt="facebook">
                            </a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include "footer.php" ?>