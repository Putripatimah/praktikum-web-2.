</div>
<footer>
    <div class="container">
        <span>&copy; <?php echo date('Y'); ?> - FTI UNISKA</span>
    </div>
</footer>
<script src="js/jquery-3.5.1.slim.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>