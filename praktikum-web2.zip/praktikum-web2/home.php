<div class="text-center mt-5">
    <img src="img/logo-uniska.png" width="200px" alt="UNISKA">
    <h3 class="mt-2">Halo, selamat datang</h3>
    <p>Materi ini mempelajari tentang <strong>CRUD</strong>
        sederhana dengan <code>PHP + MySQLI</code>
    </p>
</div>